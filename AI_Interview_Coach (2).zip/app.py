import os
import json
import streamlit as st

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

st.set_page_config(
    page_title="AI Interview Coach",
    page_icon="🎯",
    layout="centered"
)

st.title("🎯 AI Interview Coach")
st.caption("Practice smarter. Get personalized interview feedback.")

# ---------- Helpers ----------
def get_client():
    api_key = st.secrets.get("OPENAI_API_KEY", os.getenv("OPENAI_API_KEY", ""))
    if not api_key or OpenAI is None:
        return None
    return OpenAI(api_key=api_key)

def ask_ai(prompt):
    client = get_client()
    if client is None:
        return None

    response = client.responses.create(
        model="gpt-5-mini",
        input=prompt
    )
    return response.output_text

def fallback_question(role, interview_type, difficulty, number):
    questions = {
        "Technical": [
            f"Explain an important technical concept related to {role}.",
            f"Describe a project you could build as a {role}. What technologies would you use and why?",
            f"What is a common problem faced by a {role}, and how would you solve it?"
        ],
        "HR": [
            "Tell me about yourself.",
            "What are your strengths and weaknesses?",
            "Why should we select you for this role?"
        ],
        "Behavioral": [
            "Tell me about a challenging situation you faced and how you handled it.",
            "Describe a time when you worked successfully in a team.",
            "Tell me about a mistake you made and what you learned from it."
        ]
    }
    return questions[interview_type][(number - 1) % len(questions)]

def evaluate_answer(question, answer, role):
    prompt = f"""
You are an expert interview coach.

Candidate role: {role}
Interview question: {question}
Candidate answer: {answer}

Evaluate the answer. Return ONLY valid JSON in this exact structure:
{{
  "relevance": 0,
  "technical_knowledge": 0,
  "communication": 0,
  "structure": 0,
  "overall": 0,
  "strengths": ["...", "..."],
  "improvements": ["...", "..."],
  "feedback": "..."
}}

Scores must be integers from 0 to 10.
"""
    result = ask_ai(prompt)
    if result:
        try:
            return json.loads(result)
        except Exception:
            pass

    # Simple fallback so the prototype works without an API key
    length_score = min(10, max(4, len(answer.split()) // 8))
    return {
        "relevance": length_score,
        "technical_knowledge": length_score,
        "communication": 7,
        "structure": 6,
        "overall": round((length_score + length_score + 7 + 6) / 4),
        "strengths": ["You attempted the question clearly.", "Your answer gives a basis for further discussion."],
        "improvements": ["Add a concrete example.", "Structure your answer into clear points."],
        "feedback": "For a stronger answer, explain your reasoning and support it with a practical example."
    }

# ---------- State ----------
if "started" not in st.session_state:
    st.session_state.started = False
if "question_no" not in st.session_state:
    st.session_state.question_no = 1
if "scores" not in st.session_state:
    st.session_state.scores = []
if "history" not in st.session_state:
    st.session_state.history = []

# ---------- Setup ----------
if not st.session_state.started:
    st.subheader("Start your mock interview")

    role = st.selectbox(
        "Choose your target role",
        ["Software Developer", "Web Developer", "Data Analyst", "AI/ML Engineer", "Custom Role"]
    )

    if role == "Custom Role":
        role = st.text_input("Enter your role", "Software Developer")

    interview_type = st.selectbox(
        "Interview type",
        ["Technical", "HR", "Behavioral"]
    )

    difficulty = st.select_slider(
        "Difficulty",
        options=["Easy", "Medium", "Hard"],
        value="Medium"
    )

    num_questions = st.slider("Number of questions", 3, 10, 5)

    if st.button("🚀 Start Interview", use_container_width=True):
        st.session_state.role = role
        st.session_state.interview_type = interview_type
        st.session_state.difficulty = difficulty
        st.session_state.num_questions = num_questions
        st.session_state.started = True
        st.session_state.question_no = 1
        st.session_state.scores = []
        st.session_state.history = []
        st.rerun()

else:
    # ---------- Interview ----------
    if st.session_state.question_no <= st.session_state.num_questions:
        q_no = st.session_state.question_no

        if not st.session_state.history or st.session_state.history[-1].get("question_no") != q_no:
            previous = ""
            if st.session_state.history:
                previous = f"""
Previous question and answer:
Question: {st.session_state.history[-1]['question']}
Answer: {st.session_state.history[-1]['answer']}

Ask a relevant follow-up or next interview question based on the candidate's role and previous response.
"""
            prompt = f"""
Generate one {st.session_state.difficulty} difficulty {st.session_state.interview_type} interview question
for a {st.session_state.role}.

{previous}

Return only the question. Do not number it. Do not provide an answer.
"""
            generated = ask_ai(prompt)
            question = generated.strip() if generated else fallback_question(
                st.session_state.role,
                st.session_state.interview_type,
                st.session_state.difficulty,
                q_no
            )
            st.session_state.current_question = question

        st.progress(q_no / st.session_state.num_questions)
        st.write(f"### Question {q_no} of {st.session_state.num_questions}")
        st.info(st.session_state.current_question)

        answer = st.text_area(
            "Your answer",
            height=180,
            placeholder="Type your interview answer here..."
        )

        if st.button("Submit Answer", use_container_width=True):
            if not answer.strip():
                st.warning("Please enter an answer first.")
            else:
                evaluation = evaluate_answer(
                    st.session_state.current_question,
                    answer,
                    st.session_state.role
                )

                st.session_state.scores.append(evaluation)
                st.session_state.history.append({
                    "question_no": q_no,
                    "question": st.session_state.current_question,
                    "answer": answer,
                    "evaluation": evaluation
                })

                st.session_state.question_no += 1
                st.rerun()

    # ---------- Report ----------
    else:
        st.success("🎉 Interview completed!")

        if st.session_state.scores:
            avg = lambda key: round(
                sum(item.get(key, 0) for item in st.session_state.scores)
                / len(st.session_state.scores), 1
            )

            st.subheader("📊 Your Performance")

            c1, c2 = st.columns(2)
            c1.metric("Overall", f"{avg('overall')}/10")
            c2.metric("Communication", f"{avg('communication')}/10")

            c3, c4 = st.columns(2)
            c3.metric("Knowledge", f"{avg('technical_knowledge')}/10")
            c4.metric("Structure", f"{avg('structure')}/10")

            st.subheader("💪 Strengths")
            strengths = []
            for item in st.session_state.scores:
                strengths.extend(item.get("strengths", []))
            for item in list(dict.fromkeys(strengths))[:5]:
                st.write("• " + item)

            st.subheader("📈 Areas to Improve")
            improvements = []
            for item in st.session_state.scores:
                improvements.extend(item.get("improvements", []))
            for item in list(dict.fromkeys(improvements))[:5]:
                st.write("• " + item)

            st.subheader("📝 Question-wise Feedback")
            for i, item in enumerate(st.session_state.history, 1):
                with st.expander(f"Question {i}"):
                    st.write("**Question:**", item["question"])
                    st.write("**Your answer:**", item["answer"])
                    st.write("**AI feedback:**", item["evaluation"].get("feedback", ""))

        if st.button("🔄 Start New Interview", use_container_width=True):
            for key in ["started", "question_no", "scores", "history"]:
                st.session_state.pop(key, None)
            st.rerun()

st.divider()
st.caption("AI Interview Coach • Workshop MVP")
