# 🎯 AI Interview Coach

An AI-powered mock interview platform that generates interview questions, evaluates candidate answers, and provides personalized feedback.

## Features

- Role-based interviews
- Technical, HR and behavioral modes
- Easy / Medium / Hard difficulty
- Adaptive next-question generation
- AI answer evaluation
- Relevance, knowledge, communication and structure scores
- Strengths and improvement suggestions
- Final performance report
- Fallback mode so the demo still runs without an API key

## Run locally

Install Python 3.10+.

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Add OpenAI API key

Create:

`.streamlit/secrets.toml`

Add:

```toml
OPENAI_API_KEY = "your_api_key_here"
```

Never upload `secrets.toml` to GitHub.

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py`, `requirements.txt`, `README.md`, and `.gitignore`.
3. Open Streamlit Community Cloud.
4. Select the GitHub repository.
5. Set the main file to `app.py`.
6. In Advanced settings / Secrets, add:

```toml
OPENAI_API_KEY = "your_api_key_here"
```

7. Deploy.

The app will receive a public `streamlit.app` URL.
